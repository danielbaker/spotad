templateSettings =
{
    "ctor": "ExampleDefault",
    "scriptSource": "example_default.js",
    "background":
 {
     "type": { "id": "Image", "value": "image" },
     "image": "bg.jpg",
     "gradiant_start": "#555354",
     "gradiant_end": "#000"
 },
    "content": {
        "show": "true",
        "image":"cat.png"
    },
    "header":
    {
        "show": "true",
        "content": "Memory Game"
    },
    "game": {
        "show": "true",
        "images": [
            'http://parade.com/wp-content/uploads/2014/02/labrador-america-top-dog-breed-ftr.jpg',
            'http://p1.pichost.me/i/39/1621045.jpg',
            'http://www.alegoo.com/images05/animals/dogs-1/006/dogs-05.jpg',
            'http://upload.wikimedia.org/wikipedia/commons/4/4f/Maltese_puppy_blue_bow.jpg',
            'http://media1.santabanta.com/full1/Animals/Dogs/dogs-118a.jpg',
            'https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcSm__UMWO5Gs14QxJh7aW6IotFKYPDL1IyjIbGUtE7UpHWqQyi4'
        ]
    }


};

